@extends('layouts.app')

@section('content')
<div class="container my-4">
    <h2>👋 Admin Dashboard</h2>

    <div class="mt-4">
    <a href="{{ route('admin.products.index') }}" class="btn btn-primary me-2">Manage Products</a>
    <a href="{{ route('admin.orders.index') }}" class="btn btn-success me-2">View Orders</a>
    <a href="{{ route('admin.invitations.index') }}" class="btn btn-warning me-2">Manage Invitations</a>
</div>


    <div class="mt-4">
        <p>Welcome, {{ auth()->user()->name }}!</p>
        <form action="{{ route('admin.logout') }}" method="POST">
            @csrf
            <button type="submit" class="btn btn-danger">Logout</button>
        </form>
    </div>
</div>
@endsection
