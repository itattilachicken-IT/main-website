@extends('layouts.app')

@section('content')
<div class="container d-flex justify-content-center align-items-center" style="height:80vh;">
    <div class="card p-4 shadow-sm" style="width: 380px;">
        <h4 class="text-center mb-3">Admin Login</h4>

        @if($errors->any())
            <div class="alert alert-danger">{{ $errors->first() }}</div>
        @endif

        <form method="POST" action="{{ route('admin.login.post') }}">
            @csrf
            <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required autofocus>
            </div>
            <div class="mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button class="btn btn-primary w-100">Login</button>
        </form>
    </div>
</div>
@endsection
