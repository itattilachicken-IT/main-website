
@extends('layouts.app')

@section('content')
<div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Products</h2>
        <a href="{{ route('admin.products.create') }}" class="btn btn-primary">➕ Add New Product</a>
    </div>

    @if($products->count() > 0)
        <div class="row g-3">
            @foreach($products as $product)

            <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                <div class="card h-100 shadow-sm">
                    {{-- Product Image --}}
                    <img 
                        src="{{ $product->image_url }}" 
                        class="card-img-top" 
                        alt="{{ $product->name }}"
                        style="height:200px; object-fit:cover;"
                    >

                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">{{ $product->name }}</h5>
                        <p class="card-text">{{ Str::limit($product->description, 50) }}</p>
                        <p class="fw-bold">KES {{ number_format($product->price_per_kg, 2) }}</p>

                        {{-- Buttons --}}
                        <div class="mt-auto d-flex gap-1">
                            <a href="{{ route('admin.products.show', $product->id) }}" 
                               class="btn btn-sm btn-success flex-fill">View</a>

                            <a href="{{ route('admin.products.edit', $product->id) }}" 
                               class="btn btn-sm btn-info flex-fill">Edit</a>

                            <form action="{{ route('admin.products.destroy', $product->id) }}" 
                                  method="POST" class="flex-fill"
                                  onsubmit="return confirm('Are you sure you want to delete this product?');">
                                @csrf
                                @method('DELETE')
                                <button class="btn btn-sm btn-danger w-100">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>

        {{-- Pagination --}}
        <div class="mt-4 d-flex justify-content-center">
            {{ $products->links('pagination::bootstrap-5') }}
        </div>

    @else
        <div class="alert alert-info text-center">
            No products found. 
            <a href="{{ route('admin.products.create') }}" class="btn btn-sm btn-primary ms-2">Add Product</a>
        </div>
    @endif
</div>
@endsection
