@extends('layouts.app')

@section('content')
<div class="container my-4">
    <div class="card shadow-sm">
        <div class="row g-0">
            <div class="col-md-4">
                <img src="{{ asset('storage/product-images/' . basename($product->image)) }}" 
                     alt="{{ $product->name }}" 
                     class="img-fluid" 
                     style="height:100%; object-fit:cover;">
            </div>
            <div class="col-md-8">
                <div class="card-body d-flex flex-column">
                    <h2 class="card-title">{{ $product->name }}</h2>
                    <p class="card-text">{{ $product->description }}</p>
                    <p class="fw-bold">KES {{ number_format($product->price_per_kg, 2) }}</p>

                    <div class="mt-auto d-flex gap-2">
                        <a href="{{ route('admin.products.edit', $product->id) }}" class="btn btn-info">Edit</a>

                        <form action="{{ route('admin.products.destroy', $product->id) }}" method="POST" 
                              onsubmit="return confirm('Are you sure you want to delete this product?');">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-danger">Delete</button>
                        </form>

                        <a href="{{ route('admin.products.index') }}" class="btn btn-secondary">Back to List</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
