@extends('layouts.app')

@section('content')
<div class="container my-4">
    {{-- Back button --}}
    <div class="mb-3">
        <a href="{{ route('admin.products.index') }}" class="btn btn-secondary">← Back to Product List</a>
    </div>

    <div class="card shadow-sm p-4">
        <h2 class="mb-4">Edit Product</h2>

        {{-- Validation Errors --}}
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        {{-- Update Form --}}
        <form action="{{ route('admin.products.update', $product->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            {{-- Name --}}
            <div class="mb-3">
                <label class="form-label">Name</label>
                <input type="text" name="name" class="form-control" 
                       value="{{ old('name', $product->name) }}" required>
            </div>

            {{-- Description --}}
            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control" rows="3">{{ old('description', $product->description) }}</textarea>
            </div>

            {{-- Price --}}
            <div class="mb-3">
                <label class="form-label">Price per Kg (KES)</label>
                <input type="number" step="0.01" name="price_per_kg" class="form-control" 
                       value="{{ old('price_per_kg', $product->price_per_kg) }}" required>
            </div>

            {{-- Current Image --}}
            <div class="mb-3">
                <label class="form-label">Current Image</label><br>
                <img src="{{ $product->image_url }}" alt="{{ $product->name }}" 
                     class="img-fluid mb-2" style="max-height:150px;" id="currentImage">
            </div>

            {{-- Upload New Image --}}
            <div class="mb-3">
                <label class="form-label">Upload New Image (optional)</label>
                <input type="file" name="image" class="form-control" accept="image/*" onchange="previewNewImage(event)">
                <img id="newImagePreview" src="#" alt="New Image Preview" class="img-fluid mt-2" style="display:none; max-height:150px;">
            </div>

            {{-- Buttons on the same line --}}
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary flex-fill">Update Product</button>

                <form action="{{ route('admin.products.destroy', $product->id) }}" method="POST" 
                      onsubmit="return confirm('Are you sure you want to delete this product?');" class="flex-fill">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-danger w-100">Delete Product</button>
                </form>
            </div>
        </form>
    </div>
</div>

<script>
function previewNewImage(event) {
    const preview = document.getElementById('newImagePreview');
    preview.src = URL.createObjectURL(event.target.files[0]);
    preview.style.display = 'block';
}
</script>
@endsection
