<x-w::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('w.name') !!}</p>
</x-w::layouts.master>
