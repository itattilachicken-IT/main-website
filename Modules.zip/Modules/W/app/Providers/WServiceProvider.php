<?php

namespace Modules\W\Providers;


use Illuminate\Support\ServiceProvider;

class WServiceProvider extends ServiceProvider
{
    protected $moduleName = 'W';

    protected $moduleNameLower = 'w';

    public function boot(): void
    {
        $this->registerRoutes();
        $this->registerViews();
        $this->registerMigrations();
    }

    public function register(): void
    {
        // Register sub-providers if needed
        $this->app->register(RouteServiceProvider::class);
        $this->app->register(EventServiceProvider::class);
    }

    protected function registerRoutes(): void
    {
        $this->loadRoutesFrom(module_path($this->moduleName, 'routes/web.php'));
    }

    protected function registerViews(): void
    {
        $this->loadViewsFrom(module_path($this->moduleName, 'resources/views'), $this->moduleNameLower);
    }

    protected function registerMigrations(): void
    {
        $this->loadMigrationsFrom(module_path($this->moduleName, 'database/migrations'));
    }
}
