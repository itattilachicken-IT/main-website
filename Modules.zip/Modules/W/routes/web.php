<?php

use Illuminate\Support\Facades\Route;
use Modules\W\Http\Controllers\WController;

Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('ws', WController::class)->names('w');
});
