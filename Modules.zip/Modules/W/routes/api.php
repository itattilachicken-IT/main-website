<?php

use Illuminate\Support\Facades\Route;
use Modules\W\Http\Controllers\WController;

Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
    Route::apiResource('ws', WController::class)->names('w');
});
