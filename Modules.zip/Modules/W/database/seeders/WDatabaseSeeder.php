<?php

namespace Modules\W\Database\Seeders;

use Illuminate\Database\Seeder;

class WDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
