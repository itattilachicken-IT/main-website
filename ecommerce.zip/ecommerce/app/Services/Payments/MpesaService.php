<?php
// app/Services/Payments/MpesaService.php
namespace App\Services\Payments;

use Illuminate\Support\Facades\Http;
use App\Models\Order;

class MpesaService
{
    private function getAccessToken(): string
    {
        $key = config('services.mpesa.consumer_key');
        $secret = config('services.mpesa.consumer_secret');

        $url = config('services.mpesa.env') === 'sandbox'
            ? 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials'
            : 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

        $response = Http::withBasicAuth($key, $secret)->get($url);

        if (!$response->successful()) {
            throw new \Exception("M-Pesa auth failed: " . $response->body());
        }

        return $response->json()['access_token'];
    }

   public function pay(Order $order): array
{
    $timestamp = now()->format('YmdHis');
    $password = base64_encode(
        config('services.mpesa.shortcode') .
        config('services.mpesa.passkey') .
        $timestamp
    );

    $url = config('services.mpesa.env') === 'sandbox'
        ? 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest'
        : 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

    $response = Http::withToken($this->getAccessToken())
        ->post($url, [
            "BusinessShortCode" => config('services.mpesa.shortcode'),
            "Password" => $password,
            "Timestamp" => $timestamp,
            "TransactionType" => "CustomerPayBillOnline",
            "Amount" => (int) $order->paid_amount,
            "PartyA" => $order->customer_phone,
            "PartyB" => config('services.mpesa.shortcode'),
            "PhoneNumber" => $order->customer_phone,
            "CallBackURL" => config('services.mpesa.callback_url'),
            "AccountReference" => "Order-" . $order->id,
            "TransactionDesc" => "Payment for order #" . $order->id,
        ]);

    if (!$response->successful()) {
        \Log::error('M-Pesa STK Error:', $response->json());
        throw new \Exception("STK Push failed: " . $response->body());
    }

    // Save CheckoutRequestID to order
    $order->update([
        'mpesa_checkout_id' => $response['CheckoutRequestID'],
        'status' => 'pending'
    ]);

    // === Sandbox Instant Redirect ===
    $sandboxNumbers = [
        '254708374149',
        '254708374147',
        '254708374148'
    ];

    if (config('services.mpesa.env') === 'sandbox' && in_array($order->customer_phone, $sandboxNumbers)) {
        // Mark as paid immediately for sandbox test numbers
        $order->update(['status' => 'paid']);
        return ['redirect' => route('checkout.success')];
    }

    return $response->json(); // normal flow for real numbers
}

}
