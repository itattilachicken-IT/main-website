<?php

// app/Models/Order.php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'customer_name', 'customer_phone', 'customer_address',
        'total_amount', 'paid_amount', 'delivery_fee',
        'status', 'timed_out', 'payment_gateway', 'payment_method'
    ];

    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function audits()
    {
        return $this->hasMany(OrderAudit::class);
    }
}
