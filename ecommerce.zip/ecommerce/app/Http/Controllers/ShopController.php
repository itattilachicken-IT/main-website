<?php
// app/Http/Controllers/ShopController.php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ShopController extends Controller
{
    public function index()
    {
        $products = Product::all();
        return view('shop.index', compact('products'));
    }

    public function show(Product $product)
    {
        return view('shop.product', compact('product'));
    }

    public function addToCart(Request $request)
{
    $cart = session()->get('cart', []);

    $productId = $request->product_id;
    $quantity = (int) $request->quantity; // FIXED: match form input name

    if (isset($cart[$productId])) {
        $cart[$productId]['quantity'] += $quantity;
    } else {
        $product = Product::findOrFail($productId);
        $cart[$productId] = [
            "name" => $product->name,
            "price_per_kg" => $product->price_per_kg,
            "quantity" => $quantity,
        ];
    }

    session()->put('cart', $cart);

    // If AJAX request → return JSON, else redirect
    if ($request->ajax()) {
        return response()->json([
            'success' => true,
            'cart_count' => count($cart),
            'message' => "{$quantity}kg of {$product->name} added to cart."
        ]);
    }

    return redirect()->back()->with('success', 'Added to cart');
}


    public function viewCart()
    {
        $cart = session()->get('cart', []);
        $total = 0;
        foreach ($cart as $item) {
            $total += $item['price_per_kg'] * $item['quantity'];
        }
        return view('shop.cart', compact('cart', 'total'));
    }

    public function removeFromCart(Request $request)
    {
        $cart = session()->get('cart', []);
        unset($cart[$request->product_id]);
        session()->put('cart', $cart);

        if ($request->ajax()) {
            return response()->json([
                'success'    => true,
                'cart_count' => count($cart),
            ]);
        }

        return redirect()->back()->with('success', 'Removed from cart');
    }
	
	public function updateCart(Request $request)
{
    $cart = session()->get('cart', []);

    $productId = $request->product_id;
    $quantity  = (int) $request->quantity;

    if (isset($cart[$productId])) {
        if ($quantity > 0) {
            $cart[$productId]['quantity'] = $quantity;
        } else {
            // If quantity is 0 → remove product
            unset($cart[$productId]);
        }
    }

    session()->put('cart', $cart);

    $total = 0;
    foreach ($cart as $item) {
        $total += $item['price_per_kg'] * $item['quantity'];
    }

    if ($request->ajax()) {
        return response()->json([
            'success' => true,
            'cart'    => $cart,
            'cart_count' => count($cart),
            'total'   => $total,
        ]);
    }

    return redirect()->back()->with('success', 'Cart updated');
}

	
}
