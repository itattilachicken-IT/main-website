<?php
// app/Http/Controllers/CheckoutController.php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Route as DeliveryRoute;
use Illuminate\Support\Facades\DB;

use App\Services\Payments\MpesaService;
use App\Services\Payments\AirtelMoneyService;
use App\Services\Payments\CardService;
use App\Services\Payments\PaypalService;
use App\Services\Payments\BankTransferService;

class CheckoutController extends Controller
{
    const MIN_ORDER = 2000; // KES
    const MIN_DEPOSIT_PERCENT = 0.3;
    const DELIVERY_FEE = 300;

    /** Show checkout page */
    public function showCheckout()
    {
        $cart = session()->get('cart', []);
        if (!$cart || empty($cart)) {
            return redirect()->route('shop.index')->with('error', 'Cart is empty');
        }

        $total = 0;
        foreach ($cart as $item) $total += $item['price_per_kg'] * $item['quantity'];

        $routes = DeliveryRoute::all(); // Fetch all delivery routes

        return view('shop.checkout', compact('cart', 'total', 'routes'));
    }

    /** Process checkout and create order */
    public function processCheckout(Request $request)
    {
        $cart = session()->get('cart', []);
        if (!$cart || empty($cart)) return redirect()->route('shop.index')->with('error', 'Cart empty');

        $total = 0;
        foreach ($cart as $item) $total += $item['price_per_kg'] * $item['quantity'];

        if ($total < self::MIN_ORDER) {
            return redirect()->back()->with('error', 'Minimum order KES ' . self::MIN_ORDER);
        }

        $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:20',
            'address' => 'required|string|max:500',
            'route_id' => 'required|exists:routes,id'
        ]);

        $paid_amount = max($total * self::MIN_DEPOSIT_PERCENT + self::DELIVERY_FEE, self::DELIVERY_FEE);

        DB::beginTransaction();
        try {
            $order = Order::create([
                'customer_name' => $request->name,
                'customer_phone' => $request->phone,
                'customer_address' => $request->address,
                'route_id' => $request->route_id,
                'total_amount' => $total,
                'paid_amount' => $paid_amount,
                'delivery_fee' => self::DELIVERY_FEE,
                'status' => 'pending'
            ]);

            foreach ($cart as $productId => $item) {
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $productId,
                    'quantity_kg' => $item['quantity'],
                    'price_per_kg' => $item['price_per_kg'],
                    'subtotal' => $item['quantity'] * $item['price_per_kg']
                ]);
            }

            DB::commit();
            session()->forget('cart');

            // Redirect to payment selection page
            return redirect()->route('checkout.payment', $order->id);

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Error processing order: ' . $e->getMessage());
        }
    }

    /** Show payment selection page */
    public function selectPayment(Order $order)
    {
        return view('shop.payment_selection', compact('order'));
    }

    /** Process selected payment method */
    public function processPayment(Request $request, Order $order)
{
    $request->validate([
        'payment_method' => 'required|in:mpesa,airtel_money,card,paypal,bank_transfer'
    ]);

    $order->update([
        'payment_method' => $request->payment_method,
        'status' => 'payment_selected'
    ]);

    switch ($request->payment_method) {
        case 'mpesa':
            $response = (new MpesaService())->pay($order);
            // Redirect to pending page while waiting for STK
            return redirect()->route('checkout.pending', $order->id)
                ->with('message', 'M-Pesa payment initiated. Enter PIN on your phone.');
        
        case 'card':
            $paymentResponse = (new CardService())->pay($order);
            return view('shop.card_payment', [
                'order' => $order,
                'client_secret' => $paymentResponse
            ]);

        case 'paypal':
            $paymentResponse = (new PaypalService())->pay($order);
            return redirect($paymentResponse->approval_url);

        case 'bank_transfer':
        case 'airtel_money':
            return redirect()->route('checkout.pending', $order->id)
                ->with('message', ucfirst($request->payment_method) . ' selected. Await confirmation.');
    }
}


    /** Show pending payment instructions */
    public function pending(Order $order)
    {
        return view('shop.checkout_pending', compact('order'));
    }

    /** Optional: generic payment page */
    public function payment(Order $order)
    {
        return view('shop.checkout_payment', compact('order'));
    }

    /** Payment success page */
    public function success(Order $order)
    {
        return view('shop.checkout_success', compact('order'));
    }

    /** Payment failed page */
    public function failed()
    {
        return view('shop.checkout_failed');
    }
	
	public function simulateMpesa(Order $order)
{
    $order->update(['status' => 'paid']);
    return redirect()->route('checkout.success', $order->id);
}

public function simulateMpesaFail(Order $order)
{
    $order->update(['status' => 'failed']);
    return redirect()->route('checkout.failed');
}

}
