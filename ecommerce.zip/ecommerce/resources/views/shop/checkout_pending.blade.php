@extends('layouts.app')

@section('content')
<div class="container my-5">
    <div class="card shadow-lg border-warning">
        <div class="card-body text-center p-5">
            <h1 class="text-warning mb-3">⌛ Payment Pending</h1>
            <p class="lead">We’re waiting for confirmation of your payment. This usually takes a few minutes.</p>
            <p>If you paid via <strong>M-Pesa</strong> or <strong>Airtel Money</strong>, please follow the instructions on your phone.</p>
			<a href="{{ route('mpesa.simulate', $order->id) }}" class="btn btn-success">Simulate Success</a>
<a href="{{ route('mpesa.simulateFail', $order->id) }}" class="btn btn-danger">Simulate Fail</a>

            <a href="{{ route('shop.index') }}" class="btn btn-outline-warning mt-4">Back to Shop</a>
        </div>
    </div>
</div>
@endsection
