{{-- resources/views/shop/cart.blade.php --}}
@extends('layouts.app')

@section('content')
<style>
    h2 {
        color: #000;
        text-align: center;
        margin-bottom: 20px;
    }
    .cart-card {
        border: 1px solid #ddd;
        border-radius: 12px;
        background: #fff;
        padding: 15px;
        margin-bottom: 15px;
    }
    .btn-qty {
        min-width: 32px;
        font-weight: bold;
    }
    .total-box {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 10px;
        text-align: right;
        font-size: 1.2rem;
        font-weight: bold;
        color: #d32f2f;
    }
    .deposit-box {
        font-weight: bold;
        font-size: 1rem;
        text-align: right;
        color: #d32f2f;
    }
    .btn-remove {
        font-weight: bold;
    }
    #min-order-alert {
        font-weight: bold;
    }
    .flex-wrap {
        flex-wrap: wrap !important;
    }
</style>

<div class="container my-4">
    <h2>🛒 Your Cart</h2>

    @if(empty($cart))
        <div class="alert alert-info text-center">Your cart is empty. <a href="{{ route('shop.index') }}" class="btn btn-sm btn-primary ms-2">Add Items</a></div>
    @else
        <div id="min-order-alert" class="alert alert-warning text-center" style="display:none;">
            ⚠️ Your order must be at least KES 2000 (excluding delivery). Please add more items.
        </div>

        {{-- Desktop Table --}}
        <div class="d-none d-md-block">
            <table class="table table-striped align-middle shadow-sm">
                <thead class="table-dark">
                    <tr>
                        <th>Product</th>
                        <th class="text-center">Qty (Kg)</th>
                        <th>Price per Kg</th>
                        <th>Subtotal</th>
                        <th>Remove</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($cart as $productId => $item)
                    <tr id="cart-row-{{ $productId }}" data-price="{{ $item['price_per_kg'] }}">
                        <td>{{ $item['name'] }}</td>
                        <td class="text-center">
                            <div class="d-flex justify-content-center align-items-center">
                                <button class="btn btn-sm btn-outline-secondary btn-qty" onclick="updateCart({{ $productId }}, {{ $item['quantity'] + 1 }})">+</button>
                                <span class="mx-2 quantity">{{ $item['quantity'] }}</span>
                                <button class="btn btn-sm btn-outline-secondary btn-qty" onclick="updateCart({{ $productId }}, {{ $item['quantity'] - 1 }})">-</button>
                            </div>
                        </td>
                        <td>KES {{ number_format($item['price_per_kg'],2) }}</td>
                        <td class="subtotal">KES {{ number_format($item['price_per_kg'] * $item['quantity'],2) }}</td>
                        <td>
                            <button class="btn btn-danger btn-sm btn-remove" onclick="updateCart({{ $productId }}, 0)">Remove</button>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        {{-- Mobile Cards --}}
        <div class="d-md-none">
            @foreach($cart as $productId => $item)
            <div class="cart-card shadow-sm" id="cart-card-{{ $productId }}" data-price="{{ $item['price_per_kg'] }}">
                <h6>{{ $item['name'] }}</h6>
                <p>Price: KES {{ number_format($item['price_per_kg'],2) }}/Kg</p>

                <div class="d-flex align-items-center mb-2">
                    <button class="btn btn-sm btn-outline-secondary btn-qty" onclick="updateCart({{ $productId }}, {{ $item['quantity'] + 1 }})">+</button>
                    <span class="mx-3 quantity">{{ $item['quantity'] }} Kg</span>
                    <button class="btn btn-sm btn-outline-secondary btn-qty" onclick="updateCart({{ $productId }}, {{ $item['quantity'] - 1 }})">-</button>
                </div>

                <strong>Subtotal: KES <span class="subtotal">{{ number_format($item['price_per_kg'] * $item['quantity'],2) }}</span></strong>
                <button class="btn btn-danger w-100 mt-2" onclick="updateCart({{ $productId }}, 0)">Remove</button>
            </div>
            @endforeach
        </div>

        {{-- Totals & Checkout --}}
        <div class="total-box mt-3 p-3 rounded shadow-sm bg-light">
            Subtotal: KES <span id="cart-subtotal">--</span><br>
            Delivery Fee: KES <span id="delivery-fee">300</span><br>
            Total (including delivery): KES <span id="cart-total">--</span>
        </div>

        <div class="deposit-box mt-2 p-2 text-end" id="deposit-box" style="display:none;">
            Minimum Deposit: KES <span id="min-deposit">--</span> 
            <small>(30% of your order + KES 300 delivery)</small>
        </div>

        <div class="d-flex justify-content-between mt-4 flex-wrap">
            <a href="{{ route('shop.index') }}" class="btn btn-warning mb-2">➕ Add More Items</a>
            <button id="checkout-btn" class="btn btn-primary mb-2" disabled>✅ Proceed to Checkout</button>
        </div>
    @endif
</div>

@push('scripts')
<script>
document.addEventListener("DOMContentLoaded", function() {
    const DELIVERY_FEE = 300;
    const minOrderAlert = document.getElementById("min-order-alert");
    const depositBox = document.getElementById("deposit-box");
    const checkoutBtn = document.getElementById("checkout-btn");

    function updateTotals() {
        let subtotal = 0;

        document.querySelectorAll("tr[data-id], .cart-card").forEach(row => {
            const qtyEl = row.querySelector(".quantity");
            const qty = parseInt(qtyEl.textContent);
            const price = parseFloat(row.dataset.price);
            const rowSubtotal = qty * price;
            subtotal += rowSubtotal;

            const subtotalEl = row.querySelector(".subtotal");
            if(subtotalEl) subtotalEl.textContent = rowSubtotal.toLocaleString('en-US', {minimumFractionDigits:2});
        });

        // Update totals
        document.getElementById('cart-subtotal').textContent = subtotal.toLocaleString('en-US', {minimumFractionDigits:2});
        const total = subtotal + DELIVERY_FEE;
        document.getElementById('cart-total').textContent = total.toLocaleString('en-US', {minimumFractionDigits:2});

        // Minimum deposit logic
        if(subtotal < 2000){
            minOrderAlert.style.display = 'block';
            depositBox.style.display = 'none';
            checkoutBtn.disabled = true;
        } else {
            minOrderAlert.style.display = 'none';
            depositBox.style.display = 'block';
            const minDeposit = Math.round(subtotal * 0.3 + DELIVERY_FEE);
            document.getElementById('min-deposit').textContent = minDeposit.toLocaleString();
            checkoutBtn.disabled = false;
        }
    }

    updateTotals();

    // Checkout button click
    checkoutBtn.addEventListener("click", function() {
        window.location.href = "{{ route('checkout.show') }}";
    });

    // Make updateTotals global for cart increment/decrement updates
    window.updateTotals = updateTotals;

    // Cart update function
    window.updateCart = function(productId, quantity) {
        if (quantity < 0) return;

        fetch("{{ route('shop.cart.update') }}", {
            method: "POST",
            headers: {
                "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
                "Accept": "application/json",
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ product_id: productId, quantity: quantity })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                if (data.cart[productId]) {
                    // Update desktop & mobile
                    document.querySelectorAll(`#cart-row-${productId} .quantity, #cart-card-${productId} .quantity`).forEach(el => el.textContent = data.cart[productId].quantity);
                } else {
                    document.getElementById(`cart-row-${productId}`)?.remove();
                    document.getElementById(`cart-card-${productId}`)?.remove();
                }

                updateTotals();
            }
        })
        .catch(err => console.error(err));
    }
});
</script>
@endpush
@endsection
