@extends('layouts.app')

@section('content')
<div class="container my-5">
    <div class="card shadow-lg border-success">
        <div class="card-body text-center p-5">
            <h1 class="text-success mb-3">🎉 Payment Successful!</h1>
            <p class="lead">Thank you for your order. We’ve received your payment and will process your delivery soon.</p>
            <a href="{{ route('shop.index') }}" class="btn btn-outline-success mt-4">Continue Shopping</a>
        </div>
    </div>
</div>
@endsection
