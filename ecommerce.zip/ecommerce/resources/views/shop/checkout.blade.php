{{-- resources/views/shop/checkout.blade.php --}}
@extends('layouts.app')

@section('content')
<style>
    h2 { text-align:center; margin-bottom:15px; color:#000; }
    .checkout-card { border:1px solid #ddd; border-radius:10px; padding:15px; margin-bottom:10px; background:#fff; }
    .form-inline { display:flex; flex-wrap:wrap; gap:10px; align-items:center; margin-bottom:5px; }
    .form-inline label { min-width:100px; font-weight:bold; }
    .form-inline input, .form-inline select, .form-inline textarea { flex:1; }
    .total-box { background:#f8f9fa; padding:10px; border-radius:8px; font-weight:bold; text-align:right; margin-top:10px; }
    .deposit-box { font-weight:bold; text-align:right; color:#d32f2f; margin-top:5px; }
    .btn-place { width:100%; margin-top:10px; }
    .alert-min { font-weight:bold; text-align:center; padding:5px; margin-bottom:5px; }
</style>

<div class="container my-3">
    <h2>🛒 Checkout</h2>

    @if(empty($cart))
        <div class="alert alert-info text-center">Your cart is empty. <a href="{{ route('shop.index') }}">Add Items</a></div>
    @else
        <div class="checkout-card">
            <h5>Customer Details</h5>
            <form id="checkout-form" action="{{ route('checkout.process') }}" method="POST">
                @csrf

                <div class="form-inline">
                    <label for="name">Name</label>
                    <input type="text" name="name" id="name" class="form-control" required>
                </div>
                <div class="form-inline">
                    <label for="phone">Phone</label>
                    <input type="text" name="phone" id="phone" class="form-control" required>
                </div>
                <div class="form-inline">
                    <label for="address">Address</label>
                    <textarea name="address" id="address" class="form-control" rows="1" required></textarea>
                </div>
                <div class="form-inline">
                    <label for="route_id">Delivery Route</label>
                    <select name="route_id" id="route_id" class="form-select" required>
                        <option value="">Select Route</option>
                        @foreach($routes as $route)
                            <option value="{{ $route->id }}">{{ $route->name }} ({{ $route->delivery_day }})</option>
                        @endforeach
                    </select>
                </div>

                @php
                    $subtotal = 0;
                    foreach($cart as $item) $subtotal += $item['price_per_kg'] * $item['quantity'];
                    $deliveryFee = 300;
                    $total = $subtotal + $deliveryFee;
                    $minDeposit = $subtotal >= 2000 ? round($subtotal*0.3 + $deliveryFee,2) : '--';
                @endphp

                <div class="total-box">
                    Subtotal: KES {{ number_format($subtotal,2) }} <br>
                    Delivery Fee: KES {{ number_format($deliveryFee,2) }} <br>
                    Total (incl. delivery): KES {{ number_format($total,2) }}
                </div>

                <div class="deposit-box">
                    Minimum Deposit: KES {{ is_numeric($minDeposit) ? number_format($minDeposit,2) : '--' }} <br>
                    (30% of order + KES {{ $deliveryFee }} delivery)
                </div>

                @if($subtotal < 2000)
                    <div class="alert alert-warning alert-min">
                        ⚠️ Your order must be at least KES 2000 (excluding delivery). Add more items to proceed.
                    </div>
                @endif

                <div class="text-end mt-2">
                    <a href="{{ route('shop.index') }}" class="btn btn-secondary btn-sm">➕ Add More Items</a>
                </div>

                <button type="submit" class="btn btn-primary btn-place" {{ $subtotal < 2000 ? 'disabled' : '' }}>
                    ✅ Place Order
                </button>
            </form>
        </div>
    @endif
</div>
@endsection
