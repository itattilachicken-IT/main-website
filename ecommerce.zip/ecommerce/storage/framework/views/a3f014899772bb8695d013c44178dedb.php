

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="text-center">
        <h2>🕒 Order Pending</h2>
        <p>Thank you, <?php echo e($order->customer_name); ?>! Your order has been received and is currently pending.</p>
        <p>Order ID: <strong><?php echo e($order->id); ?></strong></p>
        <p>Total Amount: <strong>KES <?php echo e(number_format($order->total_amount, 2)); ?></strong></p>
        <p>Please await confirmation before delivery.</p>

        <a href="<?php echo e(route('shop.index')); ?>" class="btn btn-primary mt-3">Continue Shopping</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\ecommerce\resources\views/shop/checkout_pending.blade.php ENDPATH**/ ?>