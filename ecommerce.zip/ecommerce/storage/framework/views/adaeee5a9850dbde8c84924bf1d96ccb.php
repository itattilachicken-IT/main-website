


<?php $__env->startSection('content'); ?>
<style>
    h2 { text-align:center; margin-bottom:15px; color:#000; }
    .checkout-card { border:1px solid #ddd; border-radius:10px; padding:15px; margin-bottom:10px; background:#fff; }
    .form-inline { display:flex; flex-wrap:wrap; gap:10px; align-items:center; margin-bottom:5px; }
    .form-inline label { min-width:100px; font-weight:bold; }
    .form-inline input, .form-inline select, .form-inline textarea { flex:1; }
    .total-box { background:#f8f9fa; padding:10px; border-radius:8px; font-weight:bold; text-align:right; margin-top:10px; }
    .deposit-box { font-weight:bold; text-align:right; color:#d32f2f; margin-top:5px; }
    .btn-place { width:100%; margin-top:10px; }
    .alert-min { font-weight:bold; text-align:center; padding:5px; margin-bottom:5px; }
</style>

<div class="container my-3">
    <h2>🛒 Checkout</h2>

    <?php if(empty($cart)): ?>
        <div class="alert alert-info text-center">Your cart is empty. <a href="<?php echo e(route('shop.index')); ?>">Add Items</a></div>
    <?php else: ?>
        <div class="checkout-card">
            <h5>Customer Details</h5>
            <form id="checkout-form" action="<?php echo e(route('checkout.process')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-inline">
                    <label for="name">Name</label>
                    <input type="text" name="name" id="name" class="form-control" required>
                </div>
                <div class="form-inline">
                    <label for="phone">Phone</label>
                    <input type="text" name="phone" id="phone" class="form-control" required>
                </div>
                <div class="form-inline">
                    <label for="address">Address</label>
                    <textarea name="address" id="address" class="form-control" rows="1" required></textarea>
                </div>
                <div class="form-inline">
                    <label for="route_id">Delivery Route</label>
                    <select name="route_id" id="route_id" class="form-select" required>
                        <option value="">Select Route</option>
                        <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($route->id); ?>"><?php echo e($route->name); ?> (<?php echo e($route->delivery_day); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <?php
                    $subtotal = 0;
                    foreach($cart as $item) $subtotal += $item['price_per_kg'] * $item['quantity'];
                    $deliveryFee = 300;
                    $total = $subtotal + $deliveryFee;
                    $minDeposit = $subtotal >= 2000 ? round($subtotal*0.3 + $deliveryFee,2) : '--';
                ?>

                <div class="total-box">
                    Subtotal: KES <?php echo e(number_format($subtotal,2)); ?> <br>
                    Delivery Fee: KES <?php echo e(number_format($deliveryFee,2)); ?> <br>
                    Total (incl. delivery): KES <?php echo e(number_format($total,2)); ?>

                </div>

                <div class="deposit-box">
                    Minimum Deposit: KES <?php echo e(is_numeric($minDeposit) ? number_format($minDeposit,2) : '--'); ?> <br>
                    (30% of order + KES <?php echo e($deliveryFee); ?> delivery)
                </div>

                <?php if($subtotal < 2000): ?>
                    <div class="alert alert-warning alert-min">
                        ⚠️ Your order must be at least KES 2000 (excluding delivery). Add more items to proceed.
                    </div>
                <?php endif; ?>

                <div class="text-end mt-2">
                    <a href="<?php echo e(route('shop.index')); ?>" class="btn btn-secondary btn-sm">➕ Add More Items</a>
                </div>

                <button type="submit" class="btn btn-primary btn-place" <?php echo e($subtotal < 2000 ? 'disabled' : ''); ?>>
                    ✅ Place Order
                </button>
            </form>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\ecommerce\resources\views/shop/checkout.blade.php ENDPATH**/ ?>