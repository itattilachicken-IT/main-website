


<?php $__env->startSection('content'); ?>
<style>
    .payment-card {
        border: 1px solid #ddd;
        border-radius: 12px;
        background: #fff;
        padding: 20px;
        margin: 15px auto;
        max-width: 600px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.08);
    }

    .payment-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
        gap: 12px;
    }

    .payment-option {
        display: flex;
        align-items: center;
        padding: 12px 15px;
        border: 1px solid #ccc;
        border-radius: 8px;
        cursor: pointer;
        transition: background 0.2s, box-shadow 0.2s;
    }

    .payment-option:hover {
        background: #f8f9fa;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .payment-option input {
        margin-right: 15px;
        transform: scale(1.3);
    }

    .payment-logo {
        width: 60px;
        height: auto;
        margin-right: 12px;
    }

    .payment-label {
        font-weight: 600;
        font-size: 1.1rem;
    }

    #place-payment-btn {
        width: 100%;
        font-size: 1.1rem;
        padding: 10px;
        margin-top: 15px;
    }
</style>

<div class="container my-4">
    <div class="payment-card">
        <h4 class="text-center mb-4">Select Payment Method</h4>

        <form action="<?php echo e(route('checkout.process_payment', $order->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="payment-grid">
                <label class="payment-option">
                    <input type="radio" name="payment_method" value="mpesa" required>
                    <img src="<?php echo e(asset('images/logos/mpesa.png')); ?>" class="payment-logo" alt="M-Pesa Logo">
                    <span class="payment-label">M-Pesa</span>
                </label>

                <label class="payment-option">
                    <input type="radio" name="payment_method" value="bank_transfer" required>
                    <img src="<?php echo e(asset('images/logos/bank.png')); ?>" class="payment-logo" alt="Bank Transfer Logo">
                    <span class="payment-label">Bank Transfer</span>
                </label>

                <label class="payment-option">
                    <input type="radio" name="payment_method" value="airtel_money" required>
                    <img src="<?php echo e(asset('images/logos/airtel.png')); ?>" class="payment-logo" alt="Airtel Money Logo">
                    <span class="payment-label">Airtel Money</span>
                </label>

                <label class="payment-option">
                    <input type="radio" name="payment_method" value="card" required>
                    <img src="<?php echo e(asset('images/logos/card.jpg')); ?>" class="payment-logo" alt="Card Logo">
                    <span class="payment-label">Card</span>
                </label>

                <label class="payment-option">
                    <input type="radio" name="payment_method" value="paypal" required>
                    <img src="<?php echo e(asset('images/logos/paypal.png')); ?>" class="payment-logo" alt="PayPal Logo">
                    <span class="payment-label">PayPal</span>
                </label>
            </div>

            <button type="submit" class="btn btn-primary" id="place-payment-btn">✅ Proceed to Pay</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\ecommerce\resources\views/shop/payment_selection.blade.php ENDPATH**/ ?>