<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Attila Chicken</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f5f5f5; /* light gray background */
            color: #333;
        }

        /* Navbar */
        .navbar {
            background-color: #000; /* black navbar */
        }
        .navbar-brand img {
            height: 45px;
            width: auto;
        }
        .navbar-nav .nav-link {
            color: #fff !important;
            transition: 0.2s;
        }
        .navbar-nav .nav-link:hover {
            color: #ffcc00 !important;
        }
        .btn-cart {
            background-color: #d32f2f;
            color: #fff;
            font-weight: bold;
        }
        .btn-cart:hover {
            background-color: #ffcc00;
            color: #000;
        }

        /* Footer */
        footer {
            background: #000;
            color: #ccc;
            padding: 20px 0;
            text-align: center;
        }
        footer a {
            color: #ffcc00;
            text-decoration: none;
        }
        footer a:hover {
            color: #d32f2f;
        }
    </style>
</head>
<body>

    
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('shop.index')); ?>">
                <img src="<?php echo e(asset('storage/attila.jpg')); ?>" alt="Chicken Shop Logo">
            </a>
            <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('shop.index')); ?>">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('shop.cart.view')); ?>">Cart</a></li>
                </ul>
            </div>
        </div>
    </nav>

    
    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <footer>
        <div class="container">
            <p>&copy; <?php echo e(date('Y')); ?> Chicken Shop. All rights reserved.</p>
            <p>
                <a href="#">Privacy Policy</a> | 
                <a href="#">Terms</a>
            </p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
	<?php echo $__env->yieldPushContent('scripts'); ?>
	<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\Users\Admin\ecommerce\resources\views/layouts/app.blade.php ENDPATH**/ ?>