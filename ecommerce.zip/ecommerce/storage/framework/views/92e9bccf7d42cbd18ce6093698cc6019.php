

<?php $__env->startSection('content'); ?>
<h2><?php echo e($product->name); ?></h2>
<img src="<?php echo e($product->image); ?>" class="img-fluid mb-3">
<p><?php echo e($product->description); ?></p>
<p>KES <?php echo e(number_format($product->price_per_kg,2)); ?> per kg</p>

<form action="<?php echo e(route('shop.cart.add')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
    <div class="mb-3">
        <label>Quantity (kg)</label>
        <input type="number" name="quantity_kg" class="form-control" value="1" min="1">
    </div>
    <button class="btn btn-success">Add to Cart</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\ecommerce\resources\views/shop/product.blade.php ENDPATH**/ ?>