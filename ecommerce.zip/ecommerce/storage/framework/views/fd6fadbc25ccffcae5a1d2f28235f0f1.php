

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="card shadow-lg border-success">
        <div class="card-body text-center p-5">
            <h1 class="text-success mb-3">🎉 Payment Successful!</h1>
            <p class="lead">Thank you for your order. We’ve received your payment and will process your delivery soon.</p>
            <a href="<?php echo e(route('shop.index')); ?>" class="btn btn-outline-success mt-4">Continue Shopping</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\ecommerce\resources\views/shop/checkout_success.blade.php ENDPATH**/ ?>