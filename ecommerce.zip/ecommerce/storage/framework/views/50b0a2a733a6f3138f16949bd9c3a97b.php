

<?php $__env->startSection('content'); ?>
<style>
    body {
        background: #f5f5f5;
        color: #333;
    }
    h2 { color: #000; }

    .product-grid {
        display: grid;
        grid-template-columns: repeat(1, 1fr);
        gap: 15px;
    }
    @media (min-width: 768px) {
        .product-grid { grid-template-columns: repeat(2, 1fr); }
    }
    @media (min-width: 992px) {
        .product-grid { grid-template-columns: repeat(4, 1fr); }
    }

    .product-card {
        border: 1px solid #ddd;
        border-radius: 12px;
        overflow: hidden;
        background: #fff;
        color: #000;
        box-shadow: 0 4px 10px rgba(0,0,0,0.08);
        transition: transform 0.2s, box-shadow 0.2s;
        display: flex;
        flex-direction: column;
    }
    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 20px rgba(211, 47, 47, 0.4);
    }

    .product-img-container {
        height: 200px;
        background: #f8f9fa;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .product-img-container img {
        max-height: 100%;
        max-width: 100%;
        object-fit: contain;
    }

    .btn-primary {
        background-color: #d32f2f;
        border-color: #d32f2f;
        font-weight: bold;
    }
    .btn-primary:hover {
        background-color: #ffcc00;
        border-color: #ffcc00;
        color: #000;
    }

    .cart-button {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
    }

    /* Toast */
    #cart-toast-success,
    #cart-toast-error {
        position: fixed;
        bottom: 20px;
        right: 20px;
        min-width: 220px;
        z-index: 2000;
    }
</style>

<div class="container my-4">
    <h2 class="mb-4 text-center">🐓 Our Chicken Products</h2>

    
    <a href="<?php echo e(route('shop.cart.view')); ?>" class="btn btn-warning cart-button shadow">
        🛒 Cart (<span id="cart-count"><?php echo e(session('cart') ? count(session('cart')) : 0); ?></span>)
    </a>

    <div class="product-grid">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card product-card">
                <div class="product-img-container">
                    <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>">
                </div>

                <div class="card-body d-flex flex-column">
                    <h5 class="card-title"><?php echo e($product->name); ?></h5>
                    <p class="card-text text-muted"><?php echo e(Str::limit($product->description, 80)); ?></p>
                    <p class="fw-bold">Ksh <?php echo e(number_format($product->price_per_kg, 2)); ?> / Kg</p>

                    <div class="mt-auto d-flex justify-content-between align-items-center gap-1">
                        
                        <button class="btn btn-dark btn-sm flex-shrink-0"
                                data-bs-toggle="modal"
                                data-bs-target="#productModal<?php echo e($product->id); ?>">
                            <i class="bi bi-eye"></i> View Details
                        </button>

                        
                        <form class="add-to-cart-form d-flex align-items-center flex-grow-1 justify-content-end">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <input type="number" name="quantity" value="1" min="1"
                                   class="form-control form-control-sm me-2 text-center"
                                   style="max-width: 50px;">
                            <button type="submit" class="btn btn-primary btn-sm">
                                <i class="bi bi-cart-plus"></i> Add to Cart
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            
            <div class="modal fade" id="productModal<?php echo e($product->id); ?>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><?php echo e($product->name); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body row">
                            <div class="col-md-6">
                                <img src="<?php echo e($product->image_url); ?>" class="img-fluid rounded shadow" alt="<?php echo e($product->name); ?>">
                            </div>
                            <div class="col-md-6">
                                <p><?php echo e($product->description); ?></p>
                                <p class="fw-bold">Ksh <?php echo e(number_format($product->price_per_kg, 2)); ?> / Kg</p>

                                <form class="add-to-cart-form d-flex mt-3">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                    <input type="number" name="quantity" value="1" min="1"
                                           class="form-control me-2" style="width:80px;">
                                    <button type="submit" class="btn btn-primary">Add to Cart</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-center text-muted">No products available at the moment.</p>
        <?php endif; ?>
    </div>
</div>


<div id="cart-toast-success" class="toast align-items-center text-bg-success border-0" role="alert">
    <div class="d-flex">
        <div class="toast-body">✅ Added to cart!</div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>
</div>

<div id="cart-toast-error" class="toast align-items-center text-bg-danger border-0" role="alert">
    <div class="d-flex">
        <div class="toast-body">❌ Something went wrong.</div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    const cartCount   = document.getElementById("cart-count");
    const toastSuccess = new bootstrap.Toast(document.getElementById("cart-toast-success"));
    const toastError   = new bootstrap.Toast(document.getElementById("cart-toast-error"));

    // CSRF token from meta tag
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute("content");

    document.querySelectorAll(".add-to-cart-form").forEach(form => {
        form.addEventListener("submit", function(e) {
            e.preventDefault();

            let formData = new FormData(this);

            fetch("<?php echo e(route('shop.cart.add')); ?>", {
                method: "POST",
                headers: {
                    "X-CSRF-TOKEN": csrfToken,
                    "X-Requested-With": "XMLHttpRequest",
                    "Accept": "application/json"
                },
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    cartCount.textContent = data.cart_count;
                    toastSuccess.show();
                } else {
                    toastError.show();
                }
            })
            .catch(() => toastError.show());
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\ecommerce\resources\views/shop/index.blade.php ENDPATH**/ ?>