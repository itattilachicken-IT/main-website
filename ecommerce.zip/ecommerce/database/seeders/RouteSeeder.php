<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Route;

class RouteSeeder extends Seeder
{
    public function run(): void
    {
        $routes = [
            ['name'=>'Nairobi CBD', 'delivery_day'=>'Monday'],
            ['name'=>'Westlands', 'delivery_day'=>'Tuesday'],
            ['name'=>'Kilimani', 'delivery_day'=>'Wednesday'],
            ['name'=>'Ngong Road', 'delivery_day'=>'Thursday'],
            ['name'=>'Thika Road', 'delivery_day'=>'Friday'],
            ['name'=>'Karen', 'delivery_day'=>'Monday'],
            ['name'=>'Langata', 'delivery_day'=>'Tuesday'],
            ['name'=>'Runda', 'delivery_day'=>'Wednesday'],
            ['name'=>'Lavington', 'delivery_day'=>'Thursday'],
            ['name'=>'Embakasi', 'delivery_day'=>'Friday'],
            ['name'=>'Kahawa', 'delivery_day'=>'Monday'],
            ['name'=>'Juja', 'delivery_day'=>'Tuesday'],
            ['name'=>'Ruaka', 'delivery_day'=>'Wednesday'],
            ['name'=>'Gikambura', 'delivery_day'=>'Thursday'],
            ['name'=>'Ngong Town', 'delivery_day'=>'Friday']
        ];

        Route::insert($routes);
    }
}
