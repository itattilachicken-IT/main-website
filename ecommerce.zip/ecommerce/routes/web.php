<?php

use Illuminate\Support\Facades\Route;
// routes/web.php
use App\Http\Controllers\ShopController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\MpesaCallbackController;

Route::get('/new', function () {
    return view('welcome');
});

Route::get('/', [ShopController::class, 'index'])->name('shop.index');
Route::get('/product/{product}', [ShopController::class, 'show'])->name('shop.product.show');

Route::post('/cart/add', [ShopController::class, 'addToCart'])->name('shop.cart.add');
Route::get('/cart', [ShopController::class, 'viewCart'])->name('shop.cart.view');
Route::post('/cart/remove', [ShopController::class, 'removeFromCart'])->name('shop.cart.remove');

Route::get('/checkout', [CheckoutController::class, 'showCheckout'])->name('checkout.show');
Route::post('/checkout', [CheckoutController::class, 'processCheckout'])->name('checkout.process');
Route::get('/checkout/pending/{order}', [CheckoutController::class, 'pending'])->name('checkout.pending');
Route::get('/checkout/success/{order}', [CheckoutController::class, 'success'])->name('checkout.success');
Route::get('/checkout/failed', [CheckoutController::class, 'failed'])->name('checkout.failed');
Route::get('/checkout/timeout/{order}', [CheckoutController::class, 'timeout'])->name('checkout.timeout');
// Increment/Decrement Cart Item
Route::post('/cart/update', [ShopController::class, 'updateCart'])->name('shop.cart.update');
Route::get('/checkout/payment/{order}', [CheckoutController::class, 'selectPayment'])
    ->name('checkout.payment');

Route::post('/checkout/payment/{order}', [CheckoutController::class, 'processPayment'])
    ->name('checkout.process_payment');
	// routes/web.php
Route::get('/checkout/simulate/{order}', [CheckoutController::class, 'simulateMpesa'])->name('mpesa.simulate');
Route::get('/checkout/simulate-fail/{order}', [CheckoutController::class, 'simulateMpesaFail'])->name('mpesa.simulateFail');

Route::post('/api/mpesa/callback', [MpesaCallbackController::class, 'handle'])->name('mpesa.callback');



